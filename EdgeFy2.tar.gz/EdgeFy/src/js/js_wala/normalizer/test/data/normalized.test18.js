(function(__global) {
    var tmp0, tmp1;
    tmp0 = [];
    tmp1 = [ tmp0 ];
})(typeof global === 'undefined' ? this : global);