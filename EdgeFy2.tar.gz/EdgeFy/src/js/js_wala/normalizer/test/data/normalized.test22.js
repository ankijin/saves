(function(__global) {
    var tmp0, tmp1;
    tmp0 = 23;
    tmp1 = {
        x: tmp0
    };
})(typeof global === 'undefined' ? this : global);