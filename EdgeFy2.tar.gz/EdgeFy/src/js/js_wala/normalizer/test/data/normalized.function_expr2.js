(function(__global) {
    var tmp0, tmp1;
    tmp1 = function() {
        var x, tmp2;
        x = 23;
        tmp2 = x;
        return tmp2;
    };
    tmp0 = "f";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);
