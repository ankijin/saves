(function(__global) {
    var tmp0, tmp1;
    tmp0 = "window";
    tmp1 = __global[tmp0];
})(typeof global === 'undefined' ? this : global);
