(function (__global) {
    var tmp0, tmp1;
    tmp1 = function (a, c) {
        var tmp2;
        tmp2 = a;
        if (tmp2) {
            return;
        } else {
	    ;
        }
        return;
    };
    tmp0 = 'jQuery';
    __global[tmp0] = tmp1;
}(typeof global === 'undefined' ? this : global));
