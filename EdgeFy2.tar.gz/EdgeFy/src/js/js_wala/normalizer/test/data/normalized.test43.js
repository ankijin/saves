(function(__global) {
    var tmp0, tmp2, tmp3;
    tmp0 = 42;
    tmp1: {
        tmp2 = 23;
        tmp3 = tmp0 === tmp2;
        if (tmp3) {
	    ;
        } else {
	    ;
        }
    }
})(typeof global === 'undefined' ? this : global);