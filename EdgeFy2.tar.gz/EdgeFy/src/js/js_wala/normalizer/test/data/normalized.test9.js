(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    tmp2 = "Math";
    tmp0 = __global[tmp2];
    tmp1 = "min";
    tmp3 = 23;
    tmp5 = 23;
    tmp6 = 19;
    tmp4 = tmp5 + tmp6;
    tmp7 = tmp0[tmp1](tmp3, tmp4);
})(typeof global === 'undefined' ? this : global);