for (var p in src)
    dest[p] = src[p];