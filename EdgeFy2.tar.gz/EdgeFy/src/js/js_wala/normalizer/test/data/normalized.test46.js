(function(__global) {
    var tmp0, tmp1, tmp2;
    tmp2 = "Error";
    tmp1 = __global[tmp2];
    tmp0 = new tmp1;
    throw tmp0;
})(typeof global === 'undefined' ? this : global);