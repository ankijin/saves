(function(__global) {
    var tmp0, tmp3;
    tmp0 = function() {
        var f, tmp1;
        tmp1 = function() {
            var g, x;
            g = function() {
                var tmp2;
                tmp2 = x;
                return;
            };
            return;
        };
        f = tmp1();
        return;
    };
    tmp3 = tmp0();
})(typeof global === 'undefined' ? this : global);