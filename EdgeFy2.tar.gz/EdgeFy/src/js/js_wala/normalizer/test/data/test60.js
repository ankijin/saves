try {
    throw "";
} catch (e) {}