lbl1: lbl2: {
    break lbl1;
}