try {
    f();
} catch (e) {
    alert(e);
} finally {
    alert("done");
}