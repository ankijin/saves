(function(__global) {
    var tmp0, tmp1;
    tmp1 = function(o) {
        var tmp2;
        tmp2 = delete o;
        return;
    };
    tmp0 = "f";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);