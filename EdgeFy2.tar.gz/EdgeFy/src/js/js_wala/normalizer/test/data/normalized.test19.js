(function(__global) {
    var tmp0, tmp1, tmp2;
    tmp0 = 23;
    tmp1 = 452;
    tmp2 = [ tmp0, tmp1 ];
})(typeof global === 'undefined' ? this : global);