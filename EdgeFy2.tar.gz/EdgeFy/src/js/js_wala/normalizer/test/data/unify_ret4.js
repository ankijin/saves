// { "unify_ret": true }
function tst() {
    if(window.WeakMap)
	return true;
    return false;
}
