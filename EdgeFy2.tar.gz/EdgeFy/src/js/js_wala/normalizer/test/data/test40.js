switch (23 + 19) {
  case 42:
    var x;
    alert("yes!");
  default:
    alert("huh?");
}