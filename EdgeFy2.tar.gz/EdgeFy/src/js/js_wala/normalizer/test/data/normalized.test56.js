(function(__global) {
    var tmp0, tmp1;
    tmp0 = function() {
        var i, j;
        i = 42;
        j = i;
        return;
    };
    tmp1 = tmp0();
})(typeof global === 'undefined' ? this : global);