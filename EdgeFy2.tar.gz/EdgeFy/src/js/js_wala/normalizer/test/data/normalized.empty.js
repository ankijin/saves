(function(__global) {})(typeof global === 'undefined' ? this : global);
