(function f() {
    return f.prototype;
})();