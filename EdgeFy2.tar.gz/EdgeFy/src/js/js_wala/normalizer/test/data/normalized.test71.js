(function(__global) {
    var tmp0, tmp4;
    tmp0 = function f() {
        var tmp1, tmp2, tmp3;
        tmp2 = f;
        tmp3 = "prototype";
        tmp1 = tmp2[tmp3];
        return tmp1;
    };
    tmp4 = tmp0();
})(typeof global === 'undefined' ? this : global);