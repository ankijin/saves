function f() {
    return this.g();
}