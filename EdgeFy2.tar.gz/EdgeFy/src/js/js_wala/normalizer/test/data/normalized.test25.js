(function(__global) {
    var tmp0, tmp1, tmp2, tmp3;
    tmp1 = 23;
    tmp2 = 19;
    tmp0 = tmp1 + tmp2;
    tmp3 = {
        x: tmp0
    };
})(typeof global === 'undefined' ? this : global);