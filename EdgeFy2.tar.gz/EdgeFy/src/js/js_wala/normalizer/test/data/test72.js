var o = {
    x: 42
};
with (o) {
    alert(x);
}