(function(__global) {
    var tmp0, tmp1, tmp2, tmp3;
    tmp0 = __global;
    tmp1 = "alert";
    tmp2 = "Hi!";
    tmp3 = tmp0[tmp1](tmp2);
})(typeof global === 'undefined' ? this : global);