(function(__global) {
    var tmp0, tmp2;
    tmp0 = function(target) {
        var tmp1;
        tmp1 = target;
        if (tmp1) {
            return;
        } else {
	    ;
        }
        return;
    };
    tmp2 = tmp0();
})(typeof global === 'undefined' ? this : global);