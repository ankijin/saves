(function (__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    tmp1 = 0;
    tmp0 = 't';
    __global[tmp0] = tmp1;
    tmp2 = 2;
    tmp7 = 't';
    tmp5 = __global[tmp7];
    tmp6 = tmp2;
    tmp4 = tmp5 + tmp6;
    tmp3 = 't';
    __global[tmp3] = tmp4;
}(typeof global === 'undefined' ? this : global));
