function jQuery(a, c) {
    if (a) return;
}