(function(__global) {
    var tmp0, tmp1;
    tmp1 = 23;
    tmp0 = "x";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);