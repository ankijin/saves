(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4;
    tmp4 = "x";
    tmp2 = __global[tmp4];
    tmp3 = 1;
    tmp1 = tmp2 + tmp3;
    tmp0 = "y";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);