try {
    throw "";
} finally {}