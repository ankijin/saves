function f(i) {
    return i++;
}