(function(__global) {
    var tmp0;
    tmp0 = "hello";
})(typeof global === 'undefined' ? this : global);