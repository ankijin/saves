(function() {
    var f = function() {
        var g = function() {
            x;
        }, x;
    }();
})();