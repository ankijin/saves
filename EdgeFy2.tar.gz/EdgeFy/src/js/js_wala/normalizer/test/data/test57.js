(function(o) {
    o.i = o.j = 42;
})();