(function(__global) {
    var tmp0, tmp1;
    tmp0 = "x";
    tmp1 = eval(tmp0);
})(typeof global === 'undefined' ? this : global);