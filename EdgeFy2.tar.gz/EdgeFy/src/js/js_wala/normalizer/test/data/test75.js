function f() {
    var i = 0;
    var i = 1;
}