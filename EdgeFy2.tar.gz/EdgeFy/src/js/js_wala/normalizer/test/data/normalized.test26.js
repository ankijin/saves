(function(__global) {
    lbl: {
        break lbl;
    }
})(typeof global === 'undefined' ? this : global);