(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4, tmp5;
    tmp5 = "jQuery";
    tmp1 = __global[tmp5];
    tmp2 = "wait";
    tmp3 = tmp1[tmp2];
    tmp4 = 1;
    tmp0 = tmp3 - tmp4;
    tmp1[tmp2] = tmp0;
})(typeof global === 'undefined' ? this : global);