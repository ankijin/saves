switch (23 + 19) {
  case 42:
  case 19 + 23:
    var x;
    alert("yes!");
    break;
  default:
    alert("huh?");
}