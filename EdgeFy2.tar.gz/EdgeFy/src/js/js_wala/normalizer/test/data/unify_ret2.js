// { "unify_ret": true }
function foo() {
    var x = 23;
    return x;
}