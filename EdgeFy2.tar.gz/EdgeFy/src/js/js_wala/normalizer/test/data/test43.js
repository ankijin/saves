switch (42) {
  case 23:
}