function foo() {
    function bar() {}
    return bar;
}