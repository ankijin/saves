lbl: {
    break lbl;
}