(function(i) {
    return i += 1, 42;
})();