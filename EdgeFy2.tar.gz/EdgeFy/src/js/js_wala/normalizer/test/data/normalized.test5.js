(function(__global) {
    var tmp0, tmp1, tmp2, tmp3;
    tmp2 = "x";
    tmp0 = __global[tmp2];
    tmp1 = "f";
    tmp3 = tmp0[tmp1];
})(typeof global === 'undefined' ? this : global);