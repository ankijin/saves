function count() {
    var i = 0;
    while (i < 10)
        alert(i);
}