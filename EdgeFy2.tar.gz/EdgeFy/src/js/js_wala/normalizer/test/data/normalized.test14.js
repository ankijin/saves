(function(__global) {
    var tmp0, tmp1;
    tmp1 = 42;
    tmp0 = "y";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);