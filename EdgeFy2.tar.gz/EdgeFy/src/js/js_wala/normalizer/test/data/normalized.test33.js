(function(__global) {
    var tmp0, tmp1;
    tmp1 = function(i) {
        var tmp2, tmp3, tmp4;
        tmp2 = i;
        tmp3 = i;
        tmp4 = 1;
        i = tmp3 + tmp4;
        return tmp2;
    };
    tmp0 = "f";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);