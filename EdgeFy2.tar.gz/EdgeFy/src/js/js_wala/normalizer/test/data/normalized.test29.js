(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4;
    tmp2 = "x";
    tmp0 = __global[tmp2];
    tmp3 = "y";
    tmp1 = __global[tmp3];
    tmp4 = tmp0 + tmp1;
})(typeof global === 'undefined' ? this : global);