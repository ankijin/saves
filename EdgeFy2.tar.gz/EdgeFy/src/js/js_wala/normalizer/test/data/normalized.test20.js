(function(__global) {
    var tmp0, tmp1, tmp2, tmp3;
    tmp0 = 23;
    tmp2 = 452;
    tmp3 = [ tmp0, tmp1, tmp2 ];
})(typeof global === 'undefined' ? this : global);