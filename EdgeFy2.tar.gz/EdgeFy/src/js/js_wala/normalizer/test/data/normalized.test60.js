(function(__global) {
    var tmp0;
    try {
        tmp0 = "";
        throw tmp0;
    } catch (e) {
	;
    }
})(typeof global === 'undefined' ? this : global);