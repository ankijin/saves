(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    tmp3 = "x";
    tmp1 = __global[tmp3];
    tmp2 = "f";
    tmp0 = tmp1[tmp2];
    if (tmp0) {
        tmp7 = "x";
        tmp5 = __global[tmp7];
        tmp6 = "g";
        tmp4 = tmp5[tmp6];
    } else {
        tmp4 = tmp0;
    }
})(typeof global === 'undefined' ? this : global);