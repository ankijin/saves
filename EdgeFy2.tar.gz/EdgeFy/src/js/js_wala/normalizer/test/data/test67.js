for (; ; )
    alert("stuck!");