function f() {
  return 23;
}