(function(i) {
    return i++, 42;
})();