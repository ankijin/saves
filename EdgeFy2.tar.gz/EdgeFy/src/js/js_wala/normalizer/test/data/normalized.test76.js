(function(__global) {
    var tmp0, tmp1, tmp2;
    tmp0 = 1;
    tmp1 = 2;
    tmp2 = 3;
})(typeof global === 'undefined' ? this : global);
