(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4;
    tmp4 = "i";
    tmp2 = __global[tmp4];
    tmp3 = 1;
    tmp1 = tmp2 + tmp3;
    tmp0 = "i";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);