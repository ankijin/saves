(function(j) {
    for (var i = 0; i < j; ++i) {
        if (i % 2)
            break;

    }
})(10);