var t = 0;
t += 2;