(function(__global) {
    var tmp0, tmp1;
    tmp1 = "Object";
    tmp0 = delete __global[tmp1];
})(typeof global === 'undefined' ? this : global);