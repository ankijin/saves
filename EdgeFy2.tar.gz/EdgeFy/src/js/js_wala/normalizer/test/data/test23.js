({
    x: 23,
    get y() {
        return this.x;
    },
    set y(v) {}
});