for(var p in o)
    if(p === 'SKIP')
	continue;
