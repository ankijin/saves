(function(target) {
    if (target)
        return;

})();