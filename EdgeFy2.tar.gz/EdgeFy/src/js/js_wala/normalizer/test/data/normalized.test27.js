(function(__global) {
    lbl1: {
        lbl2: {
            break lbl1;
        }
    }
})(typeof global === 'undefined' ? this : global);