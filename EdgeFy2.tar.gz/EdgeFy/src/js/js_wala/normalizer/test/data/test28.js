if (x === y)
    alert("They are the same!");
