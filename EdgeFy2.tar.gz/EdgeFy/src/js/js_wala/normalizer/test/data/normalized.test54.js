(function(__global) {
    var tmp0, tmp5;
    tmp0 = function(i) {
        var tmp1, tmp2, tmp3, tmp4;
        tmp2 = 1;
        tmp3 = i;
        tmp4 = tmp2;
        i = tmp3 + tmp4;
        tmp1 = 42;
        return tmp1;
    };
    tmp5 = tmp0();
})(typeof global === 'undefined' ? this : global);