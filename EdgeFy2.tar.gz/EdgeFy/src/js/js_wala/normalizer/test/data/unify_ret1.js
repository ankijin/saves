// { "unify_ret": true }
function foo() {
    return 23;
}
