(function(o) {
    return o.x >>= 2, 42;
})();