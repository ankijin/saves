(function(__global) {
    debugger;
})(typeof global === 'undefined' ? this : global);