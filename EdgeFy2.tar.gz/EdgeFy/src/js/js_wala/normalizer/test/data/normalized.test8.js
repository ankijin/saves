(function(__global) {
    var tmp0, tmp1, tmp2, tmp3;
    tmp1 = "alert";
    tmp0 = __global[tmp1];
    tmp2 = "x";
    tmp3 = tmp0(tmp2);
})(typeof global === 'undefined' ? this : global);