(function(__global) {
    var tmp0;
    tmp0 = __global;
})(typeof global === 'undefined' ? this : global);
