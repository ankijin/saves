(function() {
    var i, j;
    i = j = 42;
})();