function f(x) {
    x = x.f || x.g;
}