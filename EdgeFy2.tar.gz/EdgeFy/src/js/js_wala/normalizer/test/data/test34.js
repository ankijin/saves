var i = 0;
do {
    alert(i++);
} while (i < 10);