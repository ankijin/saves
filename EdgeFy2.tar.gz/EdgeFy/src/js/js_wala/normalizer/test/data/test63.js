function f(o) {
    delete o;
}