(function(__global) {
    var tmp0, tmp1;
    tmp1 = function() {
        var tmp2;
        tmp2 = 23;
        return tmp2;
    };
    tmp0 = "f";
    __global[tmp0] = tmp1;
})(typeof global === 'undefined' ? this : global);
