switch (23 + 19) {
  default:
    alert("huh?");
    break;
  case 42:
    var x;
    alert("yes!");
    break;
}