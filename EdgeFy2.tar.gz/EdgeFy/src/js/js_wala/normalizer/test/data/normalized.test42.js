(function(__global) {
    var tmp0;
    tmp0 = 42;
    tmp1: {
	;
    }
})(typeof global === 'undefined' ? this : global);