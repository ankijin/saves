(function(__global) {
    var tmp0, tmp1, tmp2, tmp3, tmp4, tmp5;
    tmp2 = "x";
    tmp0 = __global[tmp2];
    tmp4 = "f";
    tmp3 = __global[tmp4];
    tmp1 = tmp3();
    tmp5 = tmp0[tmp1];
})(typeof global === 'undefined' ? this : global);