This package contains some common utility modules used by the other packages:

* `ast.js`: AST construction and manipulation
* `position.js`: handling source positions
* `sets.js`: simple representation of sets