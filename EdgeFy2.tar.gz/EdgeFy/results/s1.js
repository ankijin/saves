function s1(input){
	var idd2 = input;
	var temp5 = idd2-1;
	var temp6 = PROPERTIES[temp5];
	var output = temp6;
	return output;
}
