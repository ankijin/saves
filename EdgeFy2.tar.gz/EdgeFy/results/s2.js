function s2(){
	var tmpv0 = PROPERTIES;
	var output = tmpv0;
	return output;
}
