var httpProxy = require('http-proxy');

// const servers = [
    // { url: "http://localhost:3000", connections: 0 },
    // { url: "http://localhost:3001", connections: 0 },
    // { url: "http://localhost:3002", connections: 0 }
// ];


var backends = [
    { host : 'http://localhost', port: 3000, active : 0 },
    { host : 'http://localhost', port: 3001, active : 0 },
    { host : 'http://localhost', port: 3002, active : 0 },
    { host : 'http://localhost', port: 3003, active : 0 },
  ];
  
  httpProxy.createServer(function (req, res, proxy) {
    var buffer = httpProxy.buffer(req);
  
    // Pick the backend with the least active requests (naive implementation).
    var backend = backends.sort(function(a, b) {
      return a.active - b.active;
    })[0];
  
    // Add a new active request.
    backend.active++;
  
    // Proxy the request.
    proxy.proxyRequest(req, res, {
      host    : backend.host,
      port    : backend.port,
      buffer  : buffer
    });
  
    // When the response is finished, decrease the count.
    res.on('finish', function() {
      backend.active--;
    });
  }).listen(8000);