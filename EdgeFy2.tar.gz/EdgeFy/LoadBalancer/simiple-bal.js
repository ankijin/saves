/*
  simple-balancer.js: Example of a simple round robin balancer

  Copyright (c) 2013 - 2016 Charlie Robbins, Jarrett Cruger & the Contributors.

  Permission is hereby granted, free of charge, to any person obtaining
  a copy of this software and associated documentation files (the
  "Software"), to deal in the Software without restriction, including
  without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to
  permit persons to whom the Software is furnished to do so, subject to
  the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

var http = require('http'),
    httpProxy = require('http-proxy');
//
// A simple round-robin load balancing strategy.
//
// First, list the servers you want to use in your rotation.
//
var addresses = [
  {
    host: 'localhost',
    port: 3000,
    active : 0 
  },
  {
    host: 'localhost',
    port: 3001,
    active : 100 
  },
  {
    host: 'localhost',
    port: 3002,
    active : 0 
  }
];
var proxy = httpProxy.createServer();

http.createServer(function (req, res) {
  //
  // On each request, get the first location from the list...
  //
  //var target = { target: addresses.shift() };
  var target = { target: addresses.sort(function(a, b) {
    return a.active - b.active;
  })[0] };
  /** 
  var backend = addresses.sort(function(a, b) {
    return a.active - b.active;
  })[0];
  var target = {target:backend
  }
  */
  //
  // ...then proxy to the server whose 'turn' it is...
  //
  console.log('balancing request to: ', target);
  target.target.active++;
  proxy.web(req, res, target);

  setTimeout(function() {
    console.log('Blah blah blah blah extra-blah');
    target.target.active--;
    console.log(addresses)
}, 300);
  //
  // ...and then the server you just used becomes the last item in the list.
  //
  addresses.push(target.target);

  
}).listen(8000);

// Rinse; repeat; enjoy.



/**
 * var backends = [
    { host : 'http://localhost', port: 3000, active : 0 },
    { host : 'http://localhost', port: 3001, active : 0 },
    { host : 'http://localhost', port: 3002, active : 0 },
    { host : 'http://localhost', port: 3003, active : 0 },
  ];
  
  httpProxy.createServer(function (req, res, proxy) {
    var buffer = httpProxy.buffer(req);
  
    // Pick the backend with the least active requests (naive implementation).
    var backend = backends.sort(function(a, b) {
      return a.active - b.active;
    })[0];
  
    // Add a new active request.
    backend.active++;
  
    // Proxy the request.
    proxy.proxyRequest(req, res, {
      host    : backend.host,
      port    : backend.port,
      buffer  : buffer
    });
  
    // When the response is finished, decrease the count.
    res.on('finish', function() {
      backend.active--;
    });
  }).listen(8000);
 * 
 * 
 * 
 */